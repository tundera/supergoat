--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE railway;
--
-- Name: railway; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE railway WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE railway OWNER TO postgres;

\connect railway

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Account" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "providerType" text NOT NULL,
    "providerId" text NOT NULL,
    "providerAccountId" text NOT NULL,
    "refreshToken" text,
    "accessToken" text,
    "accessTokenExpires" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Account" OWNER TO postgres;

--
-- Name: Coach; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Coach" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    handle text NOT NULL,
    name text NOT NULL,
    type text,
    "isAssistant" text,
    "teamId" text
);


ALTER TABLE public."Coach" OWNER TO postgres;

--
-- Name: ColorScheme; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ColorScheme" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "primary" text NOT NULL,
    secondary text NOT NULL,
    "teamId" text
);


ALTER TABLE public."ColorScheme" OWNER TO postgres;

--
-- Name: Player; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Player" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    handle text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    height text NOT NULL,
    weight text NOT NULL,
    number text,
    "position" text,
    "teamId" text
);


ALTER TABLE public."Player" OWNER TO postgres;

--
-- Name: Session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "userId" text NOT NULL,
    expires timestamp(3) without time zone NOT NULL,
    "sessionToken" text NOT NULL,
    "accessToken" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Session" OWNER TO postgres;

--
-- Name: Team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Team" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    handle text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    city text NOT NULL,
    abbreviation text NOT NULL,
    logo text NOT NULL,
    "logoSlug" text NOT NULL,
    wins integer,
    losses integer,
    "winPercentage" double precision,
    conference text NOT NULL,
    division text NOT NULL,
    established text NOT NULL
);


ALTER TABLE public."Team" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text,
    email text,
    "emailVerified" timestamp(3) without time zone,
    image text,
    apple text,
    facebook text,
    github text,
    google text,
    twitter text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: VerificationRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."VerificationRequest" (
    id text NOT NULL,
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."VerificationRequest" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Data for Name: Account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Account" (id, "userId", "providerType", "providerId", "providerAccountId", "refreshToken", "accessToken", "accessTokenExpires", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Account" (id, "userId", "providerType", "providerId", "providerAccountId", "refreshToken", "accessToken", "accessTokenExpires", "createdAt", "updatedAt") FROM '$$PATH$$/3071.dat';

--
-- Data for Name: Coach; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Coach" (id, "createdAt", "updatedAt", handle, name, type, "isAssistant", "teamId") FROM stdin;
\.
COPY public."Coach" (id, "createdAt", "updatedAt", handle, name, type, "isAssistant", "teamId") FROM '$$PATH$$/3075.dat';

--
-- Data for Name: ColorScheme; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ColorScheme" (id, "createdAt", "updatedAt", "primary", secondary, "teamId") FROM stdin;
\.
COPY public."ColorScheme" (id, "createdAt", "updatedAt", "primary", secondary, "teamId") FROM '$$PATH$$/3077.dat';

--
-- Data for Name: Player; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Player" (id, "createdAt", "updatedAt", handle, name, slug, height, weight, number, "position", "teamId") FROM stdin;
\.
COPY public."Player" (id, "createdAt", "updatedAt", handle, name, slug, height, weight, number, "position", "teamId") FROM '$$PATH$$/3076.dat';

--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Session" (id, "userId", expires, "sessionToken", "accessToken", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Session" (id, "userId", expires, "sessionToken", "accessToken", "createdAt", "updatedAt") FROM '$$PATH$$/3072.dat';

--
-- Data for Name: Team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Team" (id, "createdAt", "updatedAt", handle, name, slug, city, abbreviation, logo, "logoSlug", wins, losses, "winPercentage", conference, division, established) FROM stdin;
\.
COPY public."Team" (id, "createdAt", "updatedAt", handle, name, slug, city, abbreviation, logo, "logoSlug", wins, losses, "winPercentage", conference, division, established) FROM '$$PATH$$/3078.dat';

--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, name, email, "emailVerified", image, apple, facebook, github, google, twitter, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."User" (id, name, email, "emailVerified", image, apple, facebook, github, google, twitter, "createdAt", "updatedAt") FROM '$$PATH$$/3073.dat';

--
-- Data for Name: VerificationRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."VerificationRequest" (id, identifier, token, expires, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."VerificationRequest" (id, identifier, token, expires, "createdAt", "updatedAt") FROM '$$PATH$$/3074.dat';

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM '$$PATH$$/3070.dat';

--
-- Name: Account Account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_pkey" PRIMARY KEY (id);


--
-- Name: Coach Coach_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Coach"
    ADD CONSTRAINT "Coach_pkey" PRIMARY KEY (id);


--
-- Name: ColorScheme ColorScheme_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ColorScheme"
    ADD CONSTRAINT "ColorScheme_pkey" PRIMARY KEY (id);


--
-- Name: Player Player_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Player"
    ADD CONSTRAINT "Player_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: Team Team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Team"
    ADD CONSTRAINT "Team_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: VerificationRequest VerificationRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VerificationRequest"
    ADD CONSTRAINT "VerificationRequest_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Account.providerId_providerAccountId_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Account.providerId_providerAccountId_unique" ON public."Account" USING btree ("providerId", "providerAccountId");


--
-- Name: Coach.handle_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Coach.handle_unique" ON public."Coach" USING btree (handle);


--
-- Name: Coach.name_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Coach.name_unique" ON public."Coach" USING btree (name);


--
-- Name: ColorScheme.teamId_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ColorScheme.teamId_unique" ON public."ColorScheme" USING btree ("teamId");


--
-- Name: Player.handle_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Player.handle_unique" ON public."Player" USING btree (handle);


--
-- Name: Player.name_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Player.name_unique" ON public."Player" USING btree (name);


--
-- Name: Player.slug_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Player.slug_unique" ON public."Player" USING btree (slug);


--
-- Name: Session.accessToken_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Session.accessToken_unique" ON public."Session" USING btree ("accessToken");


--
-- Name: Session.sessionToken_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Session.sessionToken_unique" ON public."Session" USING btree ("sessionToken");


--
-- Name: Team.abbreviation_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team.abbreviation_unique" ON public."Team" USING btree (abbreviation);


--
-- Name: Team.handle_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team.handle_unique" ON public."Team" USING btree (handle);


--
-- Name: Team.logoSlug_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team.logoSlug_unique" ON public."Team" USING btree ("logoSlug");


--
-- Name: Team.logo_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team.logo_unique" ON public."Team" USING btree (logo);


--
-- Name: Team.name_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team.name_unique" ON public."Team" USING btree (name);


--
-- Name: Team.slug_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team.slug_unique" ON public."Team" USING btree (slug);


--
-- Name: User.email_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User.email_unique" ON public."User" USING btree (email);


--
-- Name: VerificationRequest.identifier_token_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "VerificationRequest.identifier_token_unique" ON public."VerificationRequest" USING btree (identifier, token);


--
-- Name: VerificationRequest.token_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "VerificationRequest.token_unique" ON public."VerificationRequest" USING btree (token);


--
-- Name: Account Account_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Coach Coach_teamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Coach"
    ADD CONSTRAINT "Coach_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES public."Team"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ColorScheme ColorScheme_teamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ColorScheme"
    ADD CONSTRAINT "ColorScheme_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES public."Team"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Player Player_teamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Player"
    ADD CONSTRAINT "Player_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES public."Team"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

