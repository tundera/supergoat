--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.0
-- Dumped by pg_dump version 14.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE monorepo_db;
--
-- Name: monorepo_db; Type: DATABASE; Schema: -; Owner: philip.johnston
--

CREATE DATABASE monorepo_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE monorepo_db OWNER TO "philip.johnston";

\connect monorepo_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Coach; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Coach" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone,
    "updatedAt" timestamp(3) without time zone,
    name text DEFAULT ''::text NOT NULL,
    handle text DEFAULT ''::text NOT NULL,
    type text DEFAULT ''::text NOT NULL,
    "isAssistant" text DEFAULT ''::text NOT NULL,
    team text,
    image text
);


ALTER TABLE public."Coach" OWNER TO postgres;

--
-- Name: ColorScheme; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ColorScheme" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone,
    "updatedAt" timestamp(3) without time zone,
    "primary" text DEFAULT ''::text NOT NULL,
    secondary text DEFAULT ''::text NOT NULL
);


ALTER TABLE public."ColorScheme" OWNER TO postgres;

--
-- Name: Image; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Image" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone,
    "updatedAt" timestamp(3) without time zone,
    url text DEFAULT ''::text NOT NULL,
    type text,
    player text,
    team text
);


ALTER TABLE public."Image" OWNER TO postgres;

--
-- Name: Player; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Player" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone,
    "updatedAt" timestamp(3) without time zone,
    name text DEFAULT ''::text NOT NULL,
    handle text DEFAULT ''::text NOT NULL,
    slug text DEFAULT ''::text NOT NULL,
    height text DEFAULT ''::text NOT NULL,
    weight text DEFAULT ''::text NOT NULL,
    number text DEFAULT ''::text NOT NULL,
    "position" text DEFAULT ''::text NOT NULL,
    team text
);


ALTER TABLE public."Player" OWNER TO postgres;

--
-- Name: Team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Team" (
    id text NOT NULL,
    "createdAt" timestamp(3) without time zone,
    "updatedAt" timestamp(3) without time zone,
    name text DEFAULT ''::text NOT NULL,
    handle text DEFAULT ''::text NOT NULL,
    slug text DEFAULT ''::text NOT NULL,
    city text DEFAULT ''::text NOT NULL,
    abbreviation text DEFAULT ''::text NOT NULL,
    conference text DEFAULT ''::text NOT NULL,
    division text DEFAULT ''::text NOT NULL,
    established text DEFAULT ''::text NOT NULL,
    wins integer,
    losses integer,
    "winPercentage" double precision,
    "colorScheme" text
);


ALTER TABLE public."Team" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    password text NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Data for Name: Coach; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Coach" (id, "createdAt", "updatedAt", name, handle, type, "isAssistant", team, image) FROM stdin;
\.
COPY public."Coach" (id, "createdAt", "updatedAt", name, handle, type, "isAssistant", team, image) FROM '$$PATH$$/3660.dat';

--
-- Data for Name: ColorScheme; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ColorScheme" (id, "createdAt", "updatedAt", "primary", secondary) FROM stdin;
\.
COPY public."ColorScheme" (id, "createdAt", "updatedAt", "primary", secondary) FROM '$$PATH$$/3661.dat';

--
-- Data for Name: Image; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Image" (id, "createdAt", "updatedAt", url, type, player, team) FROM stdin;
\.
COPY public."Image" (id, "createdAt", "updatedAt", url, type, player, team) FROM '$$PATH$$/3662.dat';

--
-- Data for Name: Player; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Player" (id, "createdAt", "updatedAt", name, handle, slug, height, weight, number, "position", team) FROM stdin;
\.
COPY public."Player" (id, "createdAt", "updatedAt", name, handle, slug, height, weight, number, "position", team) FROM '$$PATH$$/3659.dat';

--
-- Data for Name: Team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Team" (id, "createdAt", "updatedAt", name, handle, slug, city, abbreviation, conference, division, established, wins, losses, "winPercentage", "colorScheme") FROM stdin;
\.
COPY public."Team" (id, "createdAt", "updatedAt", name, handle, slug, city, abbreviation, conference, division, established, wins, losses, "winPercentage", "colorScheme") FROM '$$PATH$$/3658.dat';

--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, name, email, password) FROM stdin;
\.
COPY public."User" (id, name, email, password) FROM '$$PATH$$/3657.dat';

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
\.
COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM '$$PATH$$/3656.dat';

--
-- Name: Coach Coach_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Coach"
    ADD CONSTRAINT "Coach_pkey" PRIMARY KEY (id);


--
-- Name: ColorScheme ColorScheme_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ColorScheme"
    ADD CONSTRAINT "ColorScheme_pkey" PRIMARY KEY (id);


--
-- Name: Image Image_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Image"
    ADD CONSTRAINT "Image_pkey" PRIMARY KEY (id);


--
-- Name: Player Player_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Player"
    ADD CONSTRAINT "Player_pkey" PRIMARY KEY (id);


--
-- Name: Team Team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Team"
    ADD CONSTRAINT "Team_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Coach_handle_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Coach_handle_key" ON public."Coach" USING btree (handle);


--
-- Name: Coach_image_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Coach_image_key" ON public."Coach" USING btree (image);


--
-- Name: Coach_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Coach_name_key" ON public."Coach" USING btree (name);


--
-- Name: Coach_team_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Coach_team_idx" ON public."Coach" USING btree (team);


--
-- Name: Image_player_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Image_player_key" ON public."Image" USING btree (player);


--
-- Name: Image_team_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Image_team_key" ON public."Image" USING btree (team);


--
-- Name: Image_url_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Image_url_key" ON public."Image" USING btree (url);


--
-- Name: Player_handle_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Player_handle_key" ON public."Player" USING btree (handle);


--
-- Name: Player_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Player_name_key" ON public."Player" USING btree (name);


--
-- Name: Player_slug_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Player_slug_key" ON public."Player" USING btree (slug);


--
-- Name: Player_team_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Player_team_idx" ON public."Player" USING btree (team);


--
-- Name: Team_abbreviation_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team_abbreviation_key" ON public."Team" USING btree (abbreviation);


--
-- Name: Team_colorScheme_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Team_colorScheme_idx" ON public."Team" USING btree ("colorScheme");


--
-- Name: Team_handle_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team_handle_key" ON public."Team" USING btree (handle);


--
-- Name: Team_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team_name_key" ON public."Team" USING btree (name);


--
-- Name: Team_slug_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Team_slug_key" ON public."Team" USING btree (slug);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Coach Coach_image_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Coach"
    ADD CONSTRAINT "Coach_image_fkey" FOREIGN KEY (image) REFERENCES public."Image"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Coach Coach_team_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Coach"
    ADD CONSTRAINT "Coach_team_fkey" FOREIGN KEY (team) REFERENCES public."Team"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Image Image_player_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Image"
    ADD CONSTRAINT "Image_player_fkey" FOREIGN KEY (player) REFERENCES public."Player"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Image Image_team_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Image"
    ADD CONSTRAINT "Image_team_fkey" FOREIGN KEY (team) REFERENCES public."Team"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Player Player_team_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Player"
    ADD CONSTRAINT "Player_team_fkey" FOREIGN KEY (team) REFERENCES public."Team"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Team Team_colorScheme_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Team"
    ADD CONSTRAINT "Team_colorScheme_fkey" FOREIGN KEY ("colorScheme") REFERENCES public."ColorScheme"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

